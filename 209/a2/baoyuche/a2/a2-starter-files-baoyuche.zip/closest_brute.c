#include "closest_brute.h"

double brute_force(struct Point P[], size_t n) 
{ 
    return 0; 
} 
