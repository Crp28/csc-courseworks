#include "closest_serial.h"

double combine_lr(struct Point P[], size_t n, struct Point mid_point, double d)
{
    return 0.0;
}

double _closest_serial(struct Point P[], size_t n)
{
    return 0.0;
}

double closest_serial(struct Point P[], size_t n)
{
    return 0.0;
}
